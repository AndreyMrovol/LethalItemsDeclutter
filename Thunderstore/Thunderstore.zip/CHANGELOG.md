# 0.0.1

Initial release

# 0.1.0

- added decorations
- added Jetpacks, Shotguns, Shotgun ammo and TZP-Inhalant

# 0.1.1

- fixed decorations patch

# 0.1.2

- hopefully fixed decorations patching properly
